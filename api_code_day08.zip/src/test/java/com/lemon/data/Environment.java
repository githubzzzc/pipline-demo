package com.lemon.data;

import java.util.HashMap;
import java.util.Map;

public class Environment {
    //声明并定义一个map（类似于postman的环境变量）
    public static Map<String,Object> envMap = new HashMap<String, Object>();
}
